create table livros(

id int not null AUTO_INCREMENT primary key,
titulo varchar (45) not null,
autor varchar (45) not null,
ano int not null,
genero varchar (45),
qtd int not null,
editora VARCHAR(45) not null,
data_entrada date not null

);

drop table livros;


