
CREATE TABLE estoque (
    ids INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(45) NOT NULL,
    data_entradas DATE NOT NULL,  
    data_saida DATE,              
    quant INT NOT NULL,           
    id_livro INT NOT NULL,        
    preco FLOAT NOT NULL,         -- 
    codigo VARCHAR(45),
    FOREIGN KEY (id_livro) REFERENCES livros(id)
);
