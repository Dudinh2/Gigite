INSERT INTO livros (titulo, autor, ano, genero, qtd, editora, data_entrada) 
VALUES
('Dom Casmurro', 'Machado de Assis', 1899, 'Romance', 12, 'Editora Abril', '2024-11-01'),
('O Primo Basílio', 'José de Alencar', 1878, 'Romance', 8, 'Editora Martins Fontes', '2024-11-02'),
('O Alquimista', 'Paulo Coelho', 1988, 'Aventura', 15, 'Editora Rocco', '2024-11-03'),
('1984', 'George Orwell', 1949, 'Distopia', 10, 'Editora Companhia das Letras', '2024-11-04'),
('O Senhor dos Anéis', 'J.R.R. Tolkien', 1954, 'Fantasia', 20, 'Editora Martins Fontes', '2024-11-05'),
('Harry Potter e a Pedra Filosofal', 'J.K. Rowling', 1997, 'Fantasia', 30, 'Editora Rocco', '2024-11-06'),
('A Moreninha', 'Joaquim Manuel de Macedo', 1844, 'Romance', 5, 'Editora Saraiva', '2024-11-07'),
('A Caverna', 'José Saramago', 2000, 'Filosofia', 3, 'Editora Companhia das Letras', '2024-11-08'),
('O Pequeno Príncipe', 'Antoine de Saint-Exupéry', 1943, 'Infantil', 25, 'Editora Globo', '2024-11-09'),
('Moby Dick', 'Herman Melville', 1851, 'Aventura', 6, 'Editora Companhia das Letras', '2024-11-10');

