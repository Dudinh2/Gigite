create table pagamento(

id int not null AUTO_INCREMENT primary key,
nome varchar (45) not null,
autor varchar (45) not null,
ano int not null,
genero varchar (45),
qtd int not null

)