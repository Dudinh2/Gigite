INSERT INTO cadastro_funci (nome, tel, email, cargo, cep, login, senha, data_entr)
VALUES 
('João Silva', 1198765, 'joao.silva@gmail.com', 'Gerente', '12345678', 'joao123', 'senha123', '2023-05-15'),
('Maria Oliveira', 2197654, 'maria.oliveira@gmail.com', 'Vendedor', '23456789', 'maria123', 'senha456', '2024-01-10'),
('Carlos Lima', 3196543, 'carlos.lima@gmail.com', 'Vendedor', '34567890', 'carlos123', 'senha789', '2023-08-20'),
('Ana Souza', 4195432, 'ana.souza@gmail.com', 'Caixa', '45678901', 'ana123', 'senha321', '2024-02-25'),
('Fernanda Costa', 5194321, 'fernanda.costa@gmail.com', 'Caixa', '56789012', 'fernanda123', 'senha654', '2023-11-15');