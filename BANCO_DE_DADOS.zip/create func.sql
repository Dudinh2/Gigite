create table cadastro_funci(

codigo int not null auto_increment primary key,
nome varchar (50) not null,
tel int not null,
email varchar (45) not null,
cargo varchar (45) not null,
cep float not null,
login varchar (45) not null,
senha varchar (45) not null,
data_entr date not null

);